import Layout from "@/components/Layout";
export default function SettingsPage(){
 return(
 <Layout>
 <div className="p-8">
 <h1 className="text-4xl font-bold">Settings</h1>
 </div>
 </Layout>);
}
