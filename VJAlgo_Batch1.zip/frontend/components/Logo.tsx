"use client";
import Link from "next/link";
export default function Logo(){
  return (
    <Link href="/dashboard" className="flex items-center gap-3">
      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-blue-600 flex items-center justify-center">
        <span className="text-white font-black text-xl">VJ</span>
      </div>
      <div>
        <div className="text-2xl font-black text-white">VJ Algo</div>
        <div className="text-xs text-slate-400">Professional Trading Platform</div>
      </div>
    </Link>
  );
}
