"use client";
import Logo from "./Logo";
import NavItem from "./NavItem";
import {HomeIcon,ChartBarIcon,ClockIcon,PresentationChartBarIcon,CurrencyRupeeIcon,Cog6ToothIcon} from "@heroicons/react/24/outline";
const menus=[
{name:"Dashboard",href:"/dashboard",icon:HomeIcon},
{name:"Stocks",href:"/stocks",icon:ChartBarIcon},
{name:"Options",href:"/options",icon:CurrencyRupeeIcon},
{name:"History",href:"/history",icon:ClockIcon},
{name:"Performance",href:"/performance",icon:PresentationChartBarIcon},
{name:"Settings",href:"/settings",icon:Cog6ToothIcon}
];
export default function Sidebar(){
 return <div className="w-72 h-screen bg-slate-950 border-r border-slate-800 flex flex-col">
 <div className="p-8"><Logo/></div>
 <div className="px-4 space-y-2">{menus.map(m=><NavItem key={m.href} {...m}/>)}</div>
 </div>;
}
