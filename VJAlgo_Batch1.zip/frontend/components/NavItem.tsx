"use client";
import Link from "next/link";
import {usePathname} from "next/navigation";
export default function NavItem({name,href,icon:Icon}:any){
 const p=usePathname();
 const active=p===href;
 return(
 <Link href={href} className={`flex items-center gap-4 rounded-xl px-5 py-4 ${active?"bg-blue-600 text-white":"text-slate-400 hover:bg-slate-800 hover:text-white"}`}>
 <Icon className="h-6 w-6"/>
 <span className="font-semibold">{name}</span>
 </Link>);
}
