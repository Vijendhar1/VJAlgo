"use client";
import Sidebar from "./Sidebar";
export default function Layout({children}:{children:React.ReactNode}){
 return(
  <div className="flex min-h-screen bg-slate-950">
   <Sidebar/>
   <div className="flex-1 overflow-y-auto">{children}</div>
  </div>
 );
}
