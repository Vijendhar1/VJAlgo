# VJAlgo - Batch 1

This batch contains the initial frontend structure.

Folders:
- frontend/components
- frontend/app/settings
